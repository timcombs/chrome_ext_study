# basic text replace extension

## replaces a given text with another given text